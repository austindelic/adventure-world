"""
File: person.py
Author: Austin Delic (austin@austindelic.com)
"""

from enum import StrEnum, auto
from src.animation import Animation, Frame, Line, Point, Segment
from src.clock import ClockProtocol
from src.entity import EngineEntity


class PersonState(StrEnum):
    IDLE = auto()
    WALKING = auto()


def _frames() -> list[Frame]:
    # contact frame (paste your segments here)
    contact: Frame = [
        Segment(Point(0.12, 0.626), Point(0.18, 0.793), Line("g", 2.0)),
        Segment(Point(0.18, 0.793), Point(0.13, 0.839), Line("g", 2.0)),
        Segment(Point(0.13, 0.839), Point(0.109, 0.893), Line("g", 2.0)),
        Segment(Point(0.109, 0.893), Point(0.13, 0.937), Line("g", 2.0)),
        Segment(Point(0.13, 0.937), Point(0.17, 0.97), Line("g", 2.0)),
        Segment(Point(0.17, 0.97), Point(0.22, 0.977), Line("g", 2.0)),
        Segment(Point(0.22, 0.977), Point(0.27, 0.946), Line("g", 2.0)),
        Segment(Point(0.27, 0.946), Point(0.298, 0.899), Line("g", 2.0)),
        Segment(Point(0.298, 0.899), Point(0.286, 0.833), Line("g", 2.0)),
        Segment(Point(0.286, 0.833), Point(0.244, 0.8), Line("g", 2.0)),
        Segment(Point(0.244, 0.8), Point(0.22, 0.789), Line("g", 2.0)),
        Segment(Point(0.22, 0.789), Point(0.2976, 0.454), Line("g", 2.0)),
        Segment(Point(0.2976, 0.454), Point(0.3057, 0.4257), Line("g", 2.0)),
        Segment(Point(0.3057, 0.4257), Point(0.3014, 0.4074), Line("g", 2.0)),
        Segment(Point(0.3014, 0.4074), Point(0.2856, 0.393), Line("g", 2.0)),
        Segment(Point(0.2856, 0.393), Point(0.267, 0.3916), Line("g", 2.0)),
        Segment(Point(0.267, 0.3916), Point(0.248, 0.4074), Line("g", 2.0)),
        Segment(Point(0.248, 0.4074), Point(0.227, 0.485), Line("g", 2.0)),
        Segment(Point(0.227, 0.485), Point(0.2224, 0.4828), Line("g", 2.0)),
        Segment(Point(0.2224, 0.4828), Point(0.3299, 0.0804), Line("g", 2.0)),
        Segment(Point(0.3299, 0.0804), Point(0.3465, 0.0874), Line("g", 2.0)),
        Segment(Point(0.3465, 0.0874), Point(0.366, 0.0806), Line("g", 2.0)),
        Segment(Point(0.366, 0.0806), Point(0.379, 0.067), Line("g", 2.0)),
        Segment(Point(0.379, 0.067), Point(0.3748, 0.0385), Line("g", 2.0)),
        Segment(Point(0.3748, 0.0385), Point(0.3223, 0.001), Line("g", 2.0)),
        Segment(Point(0.3223, 0.001), Point(0.3048, 0), Line("g", 2.0)),
        Segment(Point(0.3048, 0), Point(0.2847, 0.0122), Line("g", 2.0)),
        Segment(Point(0.2847, 0.0122), Point(0.1958, 0.3483), Line("g", 2.0)),
        Segment(Point(0.1958, 0.3483), Point(0.167, 0.234), Line("g", 2.0)),
        Segment(Point(0.167, 0.234), Point(0.0816, 0.0812), Line("g", 2.0)),
        Segment(Point(0.0816, 0.0812), Point(0.102, 0.061), Line("g", 2.0)),
        Segment(Point(0.102, 0.061), Point(0.1037, 0.032), Line("g", 2.0)),
        Segment(Point(0.1037, 0.032), Point(0.0888, 0.018), Line("g", 2.0)),
        Segment(Point(0.0888, 0.018), Point(0.0656, 0.016), Line("g", 2.0)),
        Segment(Point(0.0656, 0.016), Point(0.0164, 0.0451), Line("g", 2.0)),
        Segment(Point(0.0164, 0.0451), Point(0.0082, 0.056), Line("g", 2.0)),
        Segment(Point(0.0082, 0.056), Point(0.007, 0.0784), Line("g", 2.0)),
        Segment(Point(0.007, 0.0784), Point(0.111, 0.2655), Line("g", 2.0)),
        Segment(Point(0.111, 0.2655), Point(0.16295, 0.4948), Line("g", 2.0)),
        Segment(Point(0.16295, 0.4948), Point(0.16024, 0.4949), Line("g", 2.0)),
        Segment(Point(0.16024, 0.4949), Point(0.142, 0.4088), Line("g", 2.0)),
        Segment(Point(0.142, 0.4088), Point(0.1322, 0.3972), Line("g", 2.0)),
        Segment(Point(0.1322, 0.3972), Point(0.1114, 0.3952), Line("g", 2.0)),
        Segment(Point(0.1114, 0.3952), Point(0.0977, 0.4002), Line("g", 2.0)),
        Segment(Point(0.0977, 0.4002), Point(0.0876, 0.4116), Line("g", 2.0)),
        Segment(Point(0.0876, 0.4116), Point(0.0852, 0.4278), Line("g", 2.0)),
        Segment(Point(0.0852, 0.4278), Point(0.094, 0.4715), Line("g", 2.0)),
        Segment(Point(0.094, 0.4715), Point(0.12, 0.626), Line("g", 2.0)),
    ]
    down: Frame = [
        Segment(Point(0.311, 0.775), Point(0.272, 0.7575), Line("g", 2.0)),
        Segment(Point(0.272, 0.7575), Point(0.317, 0.5726), Line("g", 2.0)),
        Segment(Point(0.317, 0.5726), Point(0.378, 0.4086), Line("g", 2.0)),
        Segment(Point(0.378, 0.4086), Point(0.3715, 0.377), Line("g", 2.0)),
        Segment(Point(0.3715, 0.377), Point(0.342, 0.3686), Line("g", 2.0)),
        Segment(Point(0.342, 0.3686), Point(0.319, 0.3786), Line("g", 2.0)),
        Segment(Point(0.319, 0.3786), Point(0.2565, 0.557), Line("g", 2.0)),
        Segment(Point(0.2565, 0.557), Point(0.259, 0.4464), Line("g", 2.0)),
        Segment(Point(0.259, 0.4464), Point(0.339, 0.235), Line("g", 2.0)),
        Segment(Point(0.339, 0.235), Point(0.3035, 0.0546), Line("g", 2.0)),
        Segment(Point(0.3035, 0.0546), Point(0.3327, 0.051), Line("g", 2.0)),
        Segment(Point(0.3327, 0.051), Point(0.3435, 0.0261), Line("g", 2.0)),
        Segment(Point(0.3435, 0.0261), Point(0.3378, 0.01), Line("g", 2.0)),
        Segment(Point(0.3378, 0.01), Point(0.3246, 0.0005), Line("g", 2.0)),
        Segment(Point(0.3246, 0.0005), Point(0.24975, 0.0003), Line("g", 2.0)),
        Segment(Point(0.24975, 0.0003), Point(0.2404, 0.006), Line("g", 2.0)),
        Segment(Point(0.2404, 0.006), Point(0.2344, 0.0177), Line("g", 2.0)),
        Segment(Point(0.2344, 0.0177), Point(0.2354, 0.0424), Line("g", 2.0)),
        Segment(Point(0.2354, 0.0424), Point(0.2754, 0.23274), Line("g", 2.0)),
        Segment(Point(0.2754, 0.23274), Point(0.2332, 0.3442), Line("g", 2.0)),
        Segment(Point(0.2332, 0.3442), Point(0.1999, 0.2165), Line("g", 2.0)),
        Segment(Point(0.1999, 0.2165), Point(0.0744, 0.0733), Line("g", 2.0)),
        Segment(Point(0.0744, 0.0733), Point(0.0885, 0.0554), Line("g", 2.0)),
        Segment(Point(0.0885, 0.0554), Point(0.0906, 0.0362), Line("g", 2.0)),
        Segment(Point(0.0906, 0.0362), Point(0.0808, 0.02), Line("g", 2.0)),
        Segment(Point(0.0808, 0.02), Point(0.0655, 0.0094), Line("g", 2.0)),
        Segment(Point(0.0655, 0.0094), Point(0.0441, 0.0137), Line("g", 2.0)),
        Segment(Point(0.0441, 0.0137), Point(0.0068, 0.0586), Line("g", 2.0)),
        Segment(Point(0.0068, 0.0586), Point(0.0031, 0.075), Line("g", 2.0)),
        Segment(Point(0.0031, 0.075), Point(0.005, 0.0894), Line("g", 2.0)),
        Segment(Point(0.005, 0.0894), Point(0.1402, 0.2417), Line("g", 2.0)),
        Segment(Point(0.1402, 0.2417), Point(0.194, 0.4467), Line("g", 2.0)),
        Segment(Point(0.194, 0.4467), Point(0.1948, 0.5895), Line("g", 2.0)),
        Segment(Point(0.1948, 0.5895), Point(0.1172, 0.407), Line("g", 2.0)),
        Segment(Point(0.1172, 0.407), Point(0.1003, 0.389), Line("g", 2.0)),
        Segment(Point(0.1003, 0.389), Point(0.0836, 0.388), Line("g", 2.0)),
        Segment(Point(0.0836, 0.388), Point(0.0635, 0.397), Line("g", 2.0)),
        Segment(Point(0.0635, 0.397), Point(0.057, 0.419), Line("g", 2.0)),
        Segment(Point(0.057, 0.419), Point(0.062, 0.4436), Line("g", 2.0)),
        Segment(Point(0.062, 0.4436), Point(0.1375, 0.619), Line("g", 2.0)),
        Segment(Point(0.1375, 0.619), Point(0.215, 0.762), Line("g", 2.0)),
        Segment(Point(0.215, 0.762), Point(0.18, 0.784), Line("g", 2.0)),
        Segment(Point(0.18, 0.784), Point(0.152, 0.829), Line("g", 2.0)),
        Segment(Point(0.152, 0.829), Point(0.152, 0.876), Line("g", 2.0)),
        Segment(Point(0.152, 0.876), Point(0.175, 0.923), Line("g", 2.0)),
        Segment(Point(0.175, 0.923), Point(0.224, 0.954), Line("g", 2.0)),
        Segment(Point(0.224, 0.954), Point(0.268, 0.957), Line("g", 2.0)),
        Segment(Point(0.268, 0.957), Point(0.322, 0.929), Line("g", 2.0)),
        Segment(Point(0.322, 0.929), Point(0.349, 0.879), Line("g", 2.0)),
        Segment(Point(0.349, 0.879), Point(0.348, 0.827), Line("g", 2.0)),
        Segment(Point(0.348, 0.827), Point(0.327, 0.792), Line("g", 2.0)),
        Segment(Point(0.327, 0.792), Point(0.311, 0.775), Line("g", 2.0)),
    ]

    passing: Frame = [
        Segment(Point(0.2475, 0.785), Point(0.2555, 0.6046), Line("g", 2.0)),
        Segment(Point(0.2555, 0.6046), Point(0.3116, 0.43), Line("g", 2.0)),
        Segment(Point(0.3116, 0.43), Point(0.31, 0.4117), Line("g", 2.0)),
        Segment(Point(0.31, 0.4117), Point(0.2998, 0.3964), Line("g", 2.0)),
        Segment(Point(0.2998, 0.3964), Point(0.2797, 0.391), Line("g", 2.0)),
        Segment(Point(0.2797, 0.391), Point(0.2638, 0.3952), Line("g", 2.0)),
        Segment(Point(0.2638, 0.3952), Point(0.2518, 0.408), Line("g", 2.0)),
        Segment(Point(0.2518, 0.408), Point(0.2332, 0.466), Line("g", 2.0)),
        Segment(Point(0.2332, 0.466), Point(0.2577, 0.2472), Line("g", 2.0)),
        Segment(Point(0.2577, 0.2472), Point(0.208, 0.0558), Line("g", 2.0)),
        Segment(Point(0.208, 0.0558), Point(0.2317, 0.049), Line("g", 2.0)),
        Segment(Point(0.2317, 0.049), Point(0.243, 0.0325), Line("g", 2.0)),
        Segment(Point(0.243, 0.0325), Point(0.241, 0.0133), Line("g", 2.0)),
        Segment(Point(0.241, 0.0133), Point(0.2325, 0.0036), Line("g", 2.0)),
        Segment(Point(0.2325, 0.0036), Point(0.2214, 0.0), Line("g", 2.0)),
        Segment(Point(0.2214, 0.0), Point(0.1494, 0.0), Line("g", 2.0)),
        Segment(Point(0.1494, 0.0), Point(0.1427, 0.0038), Line("g", 2.0)),
        Segment(Point(0.1427, 0.0038), Point(0.1365, 0.0134), Line("g", 2.0)),
        Segment(Point(0.1365, 0.0134), Point(0.1351, 0.0276), Line("g", 2.0)),
        Segment(Point(0.1351, 0.0276), Point(0.1421, 0.0568), Line("g", 2.0)),
        Segment(Point(0.1421, 0.0568), Point(0.17645, 0.183), Line("g", 2.0)),
        Segment(Point(0.17645, 0.183), Point(0.0695, 0.0844), Line("g", 2.0)),
        Segment(Point(0.0695, 0.0844), Point(0.061, 0.0486), Line("g", 2.0)),
        Segment(Point(0.061, 0.0486), Point(0.0497, 0.0354), Line("g", 2.0)),
        Segment(Point(0.0497, 0.0354), Point(0.0367, 0.0312), Line("g", 2.0)),
        Segment(Point(0.0367, 0.0312), Point(0.0224, 0.0325), Line("g", 2.0)),
        Segment(Point(0.0224, 0.0325), Point(0.0107, 0.0403), Line("g", 2.0)),
        Segment(Point(0.0107, 0.0403), Point(0.004, 0.0516), Line("g", 2.0)),
        Segment(Point(0.004, 0.0516), Point(0.0011, 0.0649), Line("g", 2.0)),
        Segment(Point(0.0011, 0.0649), Point(0.0017, 0.0783), Line("g", 2.0)),
        Segment(Point(0.0017, 0.0783), Point(0.0078, 0.1004), Line("g", 2.0)),
        Segment(Point(0.0078, 0.1004), Point(0.0153, 0.1183), Line("g", 2.0)),
        Segment(Point(0.0153, 0.1183), Point(0.1677, 0.262), Line("g", 2.0)),
        Segment(Point(0.1677, 0.262), Point(0.17, 0.529), Line("g", 2.0)),
        Segment(Point(0.17, 0.529), Point(0.132, 0.42), Line("g", 2.0)),
        Segment(Point(0.132, 0.42), Point(0.1186, 0.4064), Line("g", 2.0)),
        Segment(Point(0.1186, 0.4064), Point(0.096, 0.403), Line("g", 2.0)),
        Segment(Point(0.096, 0.403), Point(0.081, 0.413), Line("g", 2.0)),
        Segment(Point(0.081, 0.413), Point(0.0736, 0.4316), Line("g", 2.0)),
        Segment(Point(0.0736, 0.4316), Point(0.0785, 0.454), Line("g", 2.0)),
        Segment(Point(0.0785, 0.454), Point(0.19, 0.7924), Line("g", 2.0)),
        Segment(Point(0.19, 0.7924), Point(0.1693, 0.8082), Line("g", 2.0)),
        Segment(Point(0.1693, 0.8082), Point(0.137, 0.859), Line("g", 2.0)),
        Segment(Point(0.137, 0.859), Point(0.14, 0.916), Line("g", 2.0)),
        Segment(Point(0.14, 0.916), Point(0.168, 0.96), Line("g", 2.0)),
        Segment(Point(0.168, 0.96), Point(0.217, 0.981), Line("g", 2.0)),
        Segment(Point(0.217, 0.981), Point(0.261, 0.98), Line("g", 2.0)),
        Segment(Point(0.261, 0.98), Point(0.3005, 0.96), Line("g", 2.0)),
        Segment(Point(0.3005, 0.96), Point(0.328, 0.914), Line("g", 2.0)),
        Segment(Point(0.328, 0.914), Point(0.33, 0.864), Line("g", 2.0)),
        Segment(Point(0.33, 0.864), Point(0.3126, 0.823), Line("g", 2.0)),
        Segment(Point(0.3126, 0.823), Point(0.28, 0.8), Line("g", 2.0)),
        Segment(Point(0.28, 0.8), Point(0.2475, 0.785), Line("g", 2.0)),
    ]

    up: Frame = [
        Segment(Point(0.1798, 0.7972), Point(0.1992, 0.4228), Line("g", 2.0)),
        Segment(Point(0.1992, 0.4228), Point(0.1972, 0.4187), Line("g", 2.0)),
        Segment(Point(0.1972, 0.4187), Point(0.1943, 0.4158), Line("g", 2.0)),
        Segment(Point(0.1943, 0.4158), Point(0.223, 0.2786), Line("g", 2.0)),
        Segment(Point(0.223, 0.2786), Point(0.2244, 0.26953), Line("g", 2.0)),
        Segment(Point(0.2244, 0.26953), Point(0.2238, 0.26076), Line("g", 2.0)),
        Segment(Point(0.2238, 0.26076), Point(0.2219, 0.2543), Line("g", 2.0)),
        Segment(Point(0.2219, 0.2543), Point(0.1444, 0.1141), Line("g", 2.0)),
        Segment(Point(0.1444, 0.1141), Point(0.1645, 0.0958), Line("g", 2.0)),
        Segment(Point(0.1645, 0.0958), Point(0.1673, 0.0875), Line("g", 2.0)),
        Segment(Point(0.1673, 0.0875), Point(0.1669, 0.073), Line("g", 2.0)),
        Segment(Point(0.1669, 0.073), Point(0.1614, 0.0605), Line("g", 2.0)),
        Segment(Point(0.1614, 0.0605), Point(0.1547, 0.0547), Line("g", 2.0)),
        Segment(Point(0.1547, 0.0547), Point(0.145, 0.0502), Line("g", 2.0)),
        Segment(Point(0.145, 0.0502), Point(0.1307, 0.0495), Line("g", 2.0)),
        Segment(Point(0.1307, 0.0495), Point(0.1192, 0.0538), Line("g", 2.0)),
        Segment(Point(0.1192, 0.0538), Point(0.0809, 0.081), Line("g", 2.0)),
        Segment(Point(0.0809, 0.081), Point(0.0728, 0.06), Line("g", 2.0)),
        Segment(Point(0.0728, 0.06), Point(0.0988, 0.041), Line("g", 2.0)),
        Segment(Point(0.0988, 0.041), Point(0.103, 0.031), Line("g", 2.0)),
        Segment(Point(0.103, 0.031), Point(0.1008, 0.016), Line("g", 2.0)),
        Segment(Point(0.1008, 0.016), Point(0.093, 0.0077), Line("g", 2.0)),
        Segment(Point(0.093, 0.0077), Point(0.0832, 0.0017), Line("g", 2.0)),
        Segment(Point(0.0832, 0.0017), Point(0.0642, 0.0), Line("g", 2.0)),
        Segment(Point(0.0642, 0.0), Point(0.043, 0.0035), Line("g", 2.0)),
        Segment(Point(0.043, 0.0035), Point(0.0088, 0.029), Line("g", 2.0)),
        Segment(Point(0.0088, 0.029), Point(0.0018, 0.0428), Line("g", 2.0)),
        Segment(Point(0.0018, 0.0428), Point(0.0, 0.0525), Line("g", 2.0)),
        Segment(Point(0.0, 0.0525), Point(0.005, 0.0694), Line("g", 2.0)),
        Segment(Point(0.005, 0.0694), Point(0.0873, 0.272), Line("g", 2.0)),
        Segment(Point(0.0873, 0.272), Point(0.111, 0.479), Line("g", 2.0)),
        Segment(Point(0.111, 0.479), Point(0.11, 0.509), Line("g", 2.0)),
        Segment(Point(0.11, 0.509), Point(0.093, 0.6256), Line("g", 2.0)),
        Segment(Point(0.093, 0.6256), Point(0.118, 0.809), Line("g", 2.0)),
        Segment(Point(0.118, 0.809), Point(0.096, 0.83), Line("g", 2.0)),
        Segment(Point(0.096, 0.83), Point(0.072, 0.866), Line("g", 2.0)),
        Segment(Point(0.072, 0.866), Point(0.065, 0.908), Line("g", 2.0)),
        Segment(Point(0.065, 0.908), Point(0.082, 0.9565), Line("g", 2.0)),
        Segment(Point(0.082, 0.9565), Point(0.1185, 0.987), Line("g", 2.0)),
        Segment(Point(0.1185, 0.987), Point(0.1606, 1.0), Line("g", 2.0)),
        Segment(Point(0.1606, 1.0), Point(0.214, 0.987), Line("g", 2.0)),
        Segment(Point(0.214, 0.987), Point(0.255, 0.95), Line("g", 2.0)),
        Segment(Point(0.255, 0.95), Point(0.266, 0.903), Line("g", 2.0)),
        Segment(Point(0.266, 0.903), Point(0.2556, 0.855), Line("g", 2.0)),
        Segment(Point(0.2556, 0.855), Point(0.2306, 0.824), Line("g", 2.0)),
        Segment(Point(0.2306, 0.824), Point(0.208, 0.807), Line("g", 2.0)),
        Segment(Point(0.208, 0.807), Point(0.1798, 0.7972), Line("g", 2.0)),
        # hole segment:
        Segment(Point(0.1446, 0.2495), Point(0.1522, 0.3007), Line("g", 2.0)),
        Segment(Point(0.1522, 0.3007), Point(0.1608, 0.2721), Line("g", 2.0)),
        Segment(Point(0.1608, 0.2721), Point(0.1446, 0.2495), Line("g", 2.0)),
    ]

    return [contact, down, passing, up]


class Person(EngineEntity):
    def __init__(self) -> None:
        # 1) immutable base geometry (animation frames)
        anim = Animation(_frames())

        # 2) world pose (start at origin, scale down a bit)
        super().__init__(animation=anim, start_point=Point(0.0, 0.0), size=0.2, fps=12)

        # 3) behaviour/state
        self.state: PersonState = PersonState.WALKING
        self._speed = 0.25  # units per second in world coords

    def update(self, clock: ClockProtocol) -> None:
        # animation frame selection uses Eng ineEntity.fps (12 fps here)
        # motion uses real seconds so it’s frame-rate independent
        if self.state is PersonState.WALKING:
            # reassign a NEW Point (Point is frozen/immutable)
            self.start_point = Point(
                self.start_point.x + self._speed * clock.dt, self.start_point.y
            )
        else:
            # idle: no movement
            ...
