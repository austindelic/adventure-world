name = input("get name: ")
print(name)

